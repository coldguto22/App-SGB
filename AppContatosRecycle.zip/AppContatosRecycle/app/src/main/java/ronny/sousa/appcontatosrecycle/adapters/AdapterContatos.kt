package ronny.sousa.appcontatosrecycle.adapters


import android.view.*
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.*
import ronny.sousa.appcontatosrecycle.R
import ronny.sousa.appcontatosrecycle.models.Contato

class AdapterContatos(private val lista: List<Contato>) :
    Adapter<AdapterContatos.ViewHolderContato>() {
    var posicaoClicada: Int = -1

    inner class ViewHolderContato(itemView: View) :
        RecyclerView.ViewHolder(itemView),
        View.OnCreateContextMenuListener {
        val nome: TextView = itemView.findViewById(R.id.nome_contato)
        val telefone: TextView = itemView.findViewById(R.id.telefone_contato)

        init {
            itemView.setOnLongClickListener {
                posicaoClicada = this.adapterPosition
                false
            }

            itemView.setOnCreateContextMenuListener(this)
        }

        override fun onCreateContextMenu(
            menu: ContextMenu?,
            view: View?,
            menuInfo: ContextMenu.ContextMenuInfo?
        ) {
            val inflater= MenuInflater(view?.context)
            inflater.inflate(R.menu.menu_contato,menu)
        }
        // Posterior implementação da imagem


    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): AdapterContatos.ViewHolderContato {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contato, parent, false)
        return ViewHolderContato(view)
    }

    override fun onBindViewHolder(holder: AdapterContatos.ViewHolderContato, position: Int) {
        var contato = lista[position]
        holder.nome.text = contato.nome
        holder.telefone.text = contato.telefone
    }

    override fun getItemCount(): Int {
        return lista.count()
    }


}