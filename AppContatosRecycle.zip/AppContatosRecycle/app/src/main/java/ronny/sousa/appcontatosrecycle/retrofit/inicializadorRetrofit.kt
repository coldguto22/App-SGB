package ronny.sousa.appcontatosrecycle.retrofit
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object inicializadorRetrofit {
}

val retrofit: Retrofit = Retrofit.Builder()
    .baseUrl("https://sgb-api-bj4b.onrender.com")
    .addConverterFactory(GsonConverterFactory.create())
    .build()