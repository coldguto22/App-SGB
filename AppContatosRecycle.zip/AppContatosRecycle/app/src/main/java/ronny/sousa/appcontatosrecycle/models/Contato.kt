package ronny.sousa.appcontatosrecycle.models

import com.google.gson.annotations.SerializedName

data class Contato(

    @SerializedName("_id")
    val id: String,
    val nome: String,
    val email:String,
    val telefone:String,
    val endereco:String,
    val foto:String,
)
