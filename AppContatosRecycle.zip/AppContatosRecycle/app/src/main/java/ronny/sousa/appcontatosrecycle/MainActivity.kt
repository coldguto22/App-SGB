package ronny.sousa.appcontatosrecycle

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import ronny.sousa.appcontatosrecycle.adapters.AdapterContatos
import ronny.sousa.appcontatosrecycle.models.Contato

class MainActivity : AppCompatActivity() {
    val listaContatos = ArrayList<Contato>()
    lateinit var recycleContatos:RecyclerView
    lateinit var adapter:AdapterContatos

    init {


    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recycleContatos = findViewById(R.id.listaContatos)
        adapter = AdapterContatos(listaContatos)
        recycleContatos.adapter = adapter
        recycleContatos.layoutManager=LinearLayoutManager(this)

    }

    override fun onResume() {
        super.onResume()
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        val contato = listaContatos[ adapter.posicaoClicada]
        if (item.itemId == R.id.mapa_contato)
        {
            val uri=Uri.parse("geo:0,0?q=" +
                    contato.endereco +"&z=19")
            val intent = Intent(Intent.ACTION_VIEW,uri)
            startActivity(intent)
        }
        else if (item.itemId == R.id.email_contato)
        {
            val uri=Uri.parse("mailto:" +
                    contato.email)
            val intent = Intent(Intent.ACTION_VIEW,uri)
            startActivity(intent)
        }
        else if (item.itemId == R.id.ligacao_contato)
        {
            val uri=Uri.parse("tel:" +
                    contato.telefone)
            val intent = Intent(Intent.ACTION_VIEW,uri)
            startActivity(intent)
        }
        return true

    }
}